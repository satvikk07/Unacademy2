import React from "react";
import "@elastic/eui/dist/eui_theme_dark.css";

export default function DarkTheme() {
  return <></>;
}
