import React from "react";
import "@elastic/eui/dist/eui_theme_light.css";

export default function LightTheme() {
  return <></>;
}
